// Blade-DSL Parser
// Parser with proper precedence and error handling

module Blade.Parser

open Blade.Ast
open Blade.Lexer

// ============================================================================
// Parser Types
// ============================================================================

type ParseError = {
    Message: string
    Line: int
    Col: int
}

type ParseResult<'T> = Result<'T * Token list, ParseError>

// ============================================================================
// Basic Combinators
// ============================================================================

let success value remaining : ParseResult<'T> = Ok (value, remaining)
let error msg line col : ParseResult<'T> = Error { Message = msg; Line = line; Col = col }

let currentPos (tokens: Token list) =
    match tokens with
    | t :: _ -> t.Line, t.Col
    | [] -> 0, 0

let peek (tokens: Token list) =
    match tokens with
    | t :: _ -> Some t.Kind
    | [] -> None

/// Peek, skipping any leading newlines
let peekSkipNL (tokens: Token list) =
    let rec skip toks =
        match toks with
        | t :: rest when t.Kind = TokNewline -> skip rest
        | t :: _ -> Some t.Kind
        | [] -> None
    skip tokens

let advance (tokens: Token list) =
    match tokens with
    | _ :: rest -> rest
    | [] -> []

/// Skip all leading newlines
let rec skipNL (tokens: Token list) =
    match tokens with
    | t :: rest when t.Kind = TokNewline -> skipNL rest
    | _ -> tokens

let expect kind (tokens: Token list) : ParseResult<Token> =
    match tokens with
    | t :: rest when t.Kind = kind -> Ok (t, rest)
    | t :: _ -> error (sprintf "Expected %A but got %A" kind t.Kind) t.Line t.Col
    | [] -> error (sprintf "Expected %A but got EOF" kind) 0 0

let expectIdent (tokens: Token list) : ParseResult<string> =
    match tokens with
    | t :: rest ->
        match t.Kind with
        | TokIdent name -> Ok (name, rest)
        | _ -> error (sprintf "Expected identifier but got %A" t.Kind) t.Line t.Col
    | [] -> error "Expected identifier but got EOF" 0 0

// Bind operator for chaining parsers
let (>>=) (result: ParseResult<'a>) (f: 'a -> Token list -> ParseResult<'b>) : ParseResult<'b> =
    match result with
    | Ok (v, rest) -> f v rest
    | Error e -> Error e

// Forward reference for body parser (inline or block)
let parseBodyRef : (Token list -> ParseResult<Expr>) ref = ref (fun _ -> Error { Message = "Not initialized"; Line = 0; Col = 0 })
let parseBody tokens = !parseBodyRef tokens

// ============================================================================
// Active Patterns for Token Classification (sorted by precedence)
// ============================================================================

// Literal tokens
let (|LiteralTok|_|) = function
    | TokInt v -> Some (LitInt v)
    | TokFloat v -> Some (LitFloat v)
    | TokBool v -> Some (LitBool v)
    | TokString v -> Some (LitString v)
    | TokChar v -> Some (LitChar v)
    | _ -> None

// Pipeline operators (lowest precedence combinators)
let (|PipelineOp|_|) = function
    | TokOp "|>" -> Some ()
    | _ -> None

// Choice/Alternative combinators
let (|ChoiceOp|_|) = function
    | TokOp "<|>" -> Some OpChoice
    | TokOp "<|:>" -> Some OpFallback
    | _ -> None

// Parallel combinators
let (|ParallelOp|_|) = function
    | TokOp "<&>" -> Some OpParallel
    | TokOp "<&!>" -> Some OpFusion
    | _ -> None

// Bind/Compose combinators
let (|BindOp|_|) = function
    | TokOp ">>=" -> Some OpBind
    | TokOp ">>@" -> Some OpComposeObj
    | TokOp "@>>" -> Some OpComposeMeth
    | _ -> None

// Apply/Functor combinators
let (|ApplyOp|_|) = function
    | TokOp "<@>" -> Some OpApply
    | TokOp "<$>" -> Some OpFunctor
    | _ -> None

// Array product combinator
let (|ArrayProductOp|_|) = function
    | TokOp "<*>" -> Some OpArrayProd
    | _ -> None

// Logical Or
let (|OrOp|_|) = function
    | TokOp "||" -> Some OpOr
    | _ -> None

// Logical And
let (|AndOp|_|) = function
    | TokOp "&&" -> Some OpAnd
    | _ -> None

// Equality operators
let (|EqualityOp|_|) = function
    | TokOp "==" -> Some OpEq
    | TokOp "!=" -> Some OpNeq
    | _ -> None

// Comparison operators
let (|ComparisonOp|_|) = function
    | TokOp "<" -> Some OpLt
    | TokOp "<=" -> Some OpLe
    | TokOp ">" -> Some OpGt
    | TokOp ">=" -> Some OpGe
    | _ -> None

// Additive operators (elementwise and outer)
let (|AdditiveOp|_|) = function
    | TokOp "+" -> Some OpAdd
    | TokOp "-" -> Some OpSub
    | TokOp "[+]" -> Some OpBracketAdd
    | TokOp "[-]" -> Some OpBracketSub
    | _ -> None

// Multiplicative operators (elementwise and outer)
let (|MultiplicativeOp|_|) = function
    | TokOp "*" -> Some OpMul
    | TokOp "/" -> Some OpDiv
    | TokOp "%" -> Some OpMod
    | TokOp "[*]" -> Some OpBracketMul
    | TokOp "[/]" -> Some OpBracketDiv
    | _ -> None

// Power operator
let (|PowerOp|_|) = function
    | TokOp "**" -> Some OpPow
    | _ -> None

// Unary operators
let (|UnaryOp|_|) = function
    | TokOp "-" -> Some OpNeg
    | TokOp "!" -> Some OpNot
    | _ -> None

// ============================================================================
// Helper Combinators  
// ============================================================================

let optional parser (tokens: Token list) =
    match parser tokens with
    | Ok (v, rest) -> Ok (Some v, rest)
    | Error _ -> Ok (None, tokens)

let many parser (tokens: Token list) =
    let rec loop acc toks =
        match parser toks with
        | Ok (v, rest) -> loop (v :: acc) rest
        | Error _ -> Ok (List.rev acc, toks)
    loop [] tokens

let sepBy parser sep (tokens: Token list) =
    match parser tokens with
    | Error _ -> Ok ([], tokens)
    | Ok (first, rest) ->
        let rec loop acc toks =
            match expect sep toks with
            | Error _ -> Ok (List.rev acc, toks)
            | Ok (_, afterSep) ->
                match parser afterSep with
                | Ok (v, rest') -> loop (v :: acc) rest'
                | Error _ -> Ok (List.rev acc, toks)
        loop [first] rest

// ============================================================================
// Forward Reference for Expression Parser
// ============================================================================

// The only forward reference we need - expressions can be nested
let parseExprRef : (Token list -> ParseResult<Expr>) ref = 
    ref (fun _ -> failwith "parseExpr not initialized")

let parseExpr tokens = !parseExprRef tokens

// ============================================================================
// Simple Expression Parser for Type Arguments
// Stops at > and , - used inside type angle brackets
// Has proper precedence: multiplicative binds tighter than additive
// ============================================================================

let rec parseSimpleExpr (tokens: Token list) : ParseResult<Expr> =
    parseSimpleAdditive tokens

and parseSimpleAdditive (tokens: Token list) : ParseResult<Expr> =
    parseSimpleMultiplicative tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (TokOp "+") ->
            advance toks |> parseSimpleMultiplicative >>= fun right remaining ->
            loop (ExprBinOp (OpAdd, acc, right)) remaining
        | Some (TokOp "-") ->
            advance toks |> parseSimpleMultiplicative >>= fun right remaining ->
            loop (ExprBinOp (OpSub, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseSimpleMultiplicative (tokens: Token list) : ParseResult<Expr> =
    parseSimplePrimary tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (TokOp "*") ->
            advance toks |> parseSimplePrimary >>= fun right remaining ->
            loop (ExprBinOp (OpMul, acc, right)) remaining
        | Some (TokOp "/") ->
            advance toks |> parseSimplePrimary >>= fun right remaining ->
            loop (ExprBinOp (OpDiv, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseSimplePrimary (tokens: Token list) : ParseResult<Expr> =
    match peek tokens with
    | Some (LiteralTok lit) -> success (ExprLit lit) (advance tokens)
    | Some (TokIdent name) -> success (ExprVar name) (advance tokens)
    | Some TokLParen ->
        advance tokens |> parseSimpleExpr >>= fun expr afterExpr ->
        expect TokRParen afterExpr >>= fun _ remaining ->
        success expr remaining
    | Some kind ->
        let line, col = currentPos tokens
        error (sprintf "Expected simple expression but got %A" kind) line col
    | None ->
        error "Expected expression but got EOF" 0 0

// ============================================================================
// Literal Parsing
// ============================================================================

let parseLiteral (tokens: Token list) : ParseResult<Literal> =
    match tokens with
    | t :: rest ->
        match t.Kind with
        | TokInt v -> success (LitInt v) rest
        | TokFloat v -> success (LitFloat v) rest
        | TokBool v -> success (LitBool v) rest
        | TokString v -> success (LitString v) rest
        | TokChar v -> success (LitChar v) rest
        | _ -> error "Expected literal" t.Line t.Col
    | [] -> error "Expected literal but got EOF" 0 0

// ============================================================================
// Type Expression Parsing
// ============================================================================

/// Parse a rank expression (for T^r syntax)
/// Can be: integer literal, arity keyword, or simple identifier
let parseRankExpr (tokens: Token list) : ParseResult<Expr> =
    match peek tokens with
    | Some (TokInt n) -> 
        success (ExprLit (LitInt n)) (advance tokens)
    | Some (TokKeyword KwArity) -> 
        success ExprArity (advance tokens)
    | Some (TokIdent name) -> 
        success (ExprVar name) (advance tokens)
    | Some t ->
        let line, col = currentPos tokens
        error (sprintf "Expected rank expression (integer, arity, or identifier), got %A" t) line col
    | None ->
        error "Expected rank expression but got EOF" 0 0

let rec parseTypeExpr (tokens: Token list) : ParseResult<TypeExpr> =
    parseTypeAtom tokens >>= fun first rest ->
    match peek rest with
    | Some (TokOp "->") ->
        advance rest |> parseTypeExpr >>= fun ret remaining ->
        success (TyFunc ([first], ret)) remaining
    | _ -> success first rest

and parseTypeAtom (tokens: Token list) : ParseResult<TypeExpr> =
    match peek tokens with
    | Some (TokKeyword KwArray) ->
        // Array<T like I1, I2>
        advance tokens |> expect (TokOp "<") >>= fun _ afterLt ->
        parseTypeExpr afterLt >>= fun elemType afterElem ->
        match peek afterElem with
        | Some (TokKeyword KwLike) ->
            // After 'like', only expect index types (Idx or SymIdx)
            advance afterElem |> sepBy parseIndexType TokComma >>= fun indexTypes afterIndices ->
            expect (TokOp ">") afterIndices >>= fun _ remaining ->
            success (TyArray (elemType, indexTypes)) remaining
        | _ ->
            expect (TokOp ">") afterElem >>= fun _ remaining ->
            success (TyArray (elemType, [])) remaining
    
    | Some (TokKeyword KwPoly) ->
        // Poly<T^r> - arity-polymorphic pack type
        advance tokens |> expect (TokOp "<") >>= fun _ afterLt ->
        parseTypeExpr afterLt >>= fun innerType afterInner ->
        expect (TokOp ">") afterInner >>= fun _ remaining ->
        success (TyPoly innerType) remaining
    
    | Some (TokKeyword KwIdx) ->
        parseIndexType tokens
    
    | Some (TokKeyword KwSymIdx) ->
        parseIndexType tokens
    
    | Some TokLParen ->
        // Tuple type or parenthesized
        advance tokens |> sepBy parseTypeExpr TokComma >>= fun types afterTypes ->
        expect TokRParen afterTypes >>= fun _ remaining ->
        match types with
        | [single] -> success single remaining
        | _ -> success (TyTuple types) remaining
    
    | Some (TokIdent name) ->
        // Named type, possibly with type args or abstract array rank (T^r)
        let afterName = advance tokens
        match peek afterName with
        | Some (TokOp "<") ->
            advance afterName |> sepBy parseTypeExpr TokComma >>= fun args afterArgs ->
            expect (TokOp ">") afterArgs >>= fun _ remaining ->
            success (TyNamed (name, args)) remaining
        | Some (TokOp "^") ->
            // Abstract array type: T^r or T^arity
            advance afterName |> parseRankExpr >>= fun rankExpr remaining ->
            success (TyAbstractArray (TyNamed (name, []), rankExpr, None)) remaining
        | _ ->
            success (TyNamed (name, [])) afterName
    
    | Some kind ->
        let line, col = currentPos tokens
        error (sprintf "Unexpected token in type: %A" kind) line col
    
    | None ->
        error "Expected type but got EOF" 0 0

// Parse index types specifically - Idx<extent> or SymIdx<arity, extent>
// These are self-contained with their own < > brackets
and parseIndexType (tokens: Token list) : ParseResult<TypeExpr> =
    match peek tokens with
    | Some (TokKeyword KwIdx) ->
        advance tokens |> expect (TokOp "<") >>= fun _ afterLt ->
        parseSimpleExpr afterLt >>= fun extent afterExtent ->
        expect (TokOp ">") afterExtent >>= fun _ remaining ->
        success (TyIdx extent) remaining
    
    | Some (TokKeyword KwSymIdx) ->
        advance tokens |> expect (TokOp "<") >>= fun _ afterLt ->
        parseLiteral afterLt >>= fun arityLit afterArity ->
        expect TokComma afterArity >>= fun _ afterComma ->
        parseSimpleExpr afterComma >>= fun extent afterExtent ->
        expect (TokOp ">") afterExtent >>= fun _ remaining ->
        let arity = match arityLit with LitInt n -> int n | _ -> 2
        success (TySymIdx (arity, extent)) remaining
    
    | Some kind ->
        let line, col = currentPos tokens
        error (sprintf "Expected index type (Idx or SymIdx) but got %A" kind) line col
    
    | None ->
        error "Expected index type but got EOF" 0 0

// ============================================================================
// Pattern Parsing
// ============================================================================

let rec parsePattern (tokens: Token list) : ParseResult<Pattern> =
    parseAtomicPattern tokens >>= fun left rest ->
    match peek rest with
    | Some TokColonColon ->
        advance rest |> parsePattern >>= fun right remaining ->
        success (PatCons (left, right)) remaining
    | _ -> success left rest

and parseAtomicPattern (tokens: Token list) : ParseResult<Pattern> =
    match peek tokens with
    | Some TokUnderscore ->
        success PatWildcard (advance tokens)
    
    | Some (TokIdent name) ->
        success (PatVar name) (advance tokens)
    
    | Some (TokInt v) ->
        success (PatLit (LitInt v)) (advance tokens)
    
    | Some (TokBool v) ->
        success (PatLit (LitBool v)) (advance tokens)
    
    | Some (TokString v) ->
        success (PatLit (LitString v)) (advance tokens)
    
    | Some TokLParen ->
        advance tokens |> sepBy parsePattern TokComma >>= fun pats afterPats ->
        expect TokRParen afterPats >>= fun _ remaining ->
        match pats with
        | [] -> success (PatLit LitUnit) remaining
        | [single] -> success single remaining
        | _ -> success (PatTuple pats) remaining
    
    | Some kind ->
        let line, col = currentPos tokens
        error (sprintf "Unexpected token in pattern: %A" kind) line col
    
    | None ->
        error "Expected pattern but got EOF" 0 0

// ============================================================================
// Expression Parsing - Precedence Climbing
// ============================================================================

// Precedence levels (lowest to highest):
// 1. Assignment =
// 2. Pipeline |>
// 3. Choice <|>
// 4. Parallel <&>
// 5. Bind >>=
// 6. Apply <@>
// 7. Array product <*>
// 8. Or ||
// 9. And &&
// 10. Equality == !=
// 11. Comparison < <= > >=
// 12. Cons ::
// 13. Additive + -
// 14. Multiplicative * / %
// 15. Power **
// 16. Unary - !
// 17. Postfix (call, index, field)
// 18. Primary (literals, variables, etc.)

// Helper for parsing comma-separated identifier lists (for where clauses)
let parseIdentList (tokens: Token list) : ParseResult<string list> =
    let rec loop acc toks =
        match toks with
        | t :: rest when (match t.Kind with TokIdent _ -> true | _ -> false) ->
            let name = match t.Kind with TokIdent n -> n | _ -> ""
            match rest with
            | t2 :: rest2 when t2.Kind = TokComma -> loop (name :: acc) rest2
            | _ -> Ok (List.rev (name :: acc), rest)
        | _ -> 
            if List.isEmpty acc then
                let line, col = currentPos toks
                Error { Message = "Expected identifier"; Line = line; Col = col }
            else
                Ok (List.rev acc, toks)
    loop [] tokens

// Where clause parsing (used by both function declarations and lambdas)
let parseWhereClause (tokens: Token list) : ParseResult<WhereClause> =
    let rec loop comms pars toks =
        match peek toks with
        | Some (TokKeyword KwComm) ->
            advance toks |> expect TokLParen >>= fun _ afterLParen ->
            parseIdentList afterLParen >>= fun names afterNames ->
            expect TokRParen afterNames >>= fun _ remaining ->
            loop (names :: comms) pars remaining
        | Some TokComma ->
            loop comms pars (advance toks)
        | _ ->
            success { 
                Commutativity = List.rev comms
                Parallelism = pars
                TDims = []
            } toks
    loop [] [] tokens

let rec parseExprImpl (tokens: Token list) : ParseResult<Expr> =
    parseAssignment tokens

/// Parse a body expression - either a block {...} or an inline expression
/// Inline expressions stop at newline (consumed) or other terminators
and parseInlineOrBlock (tokens: Token list) : ParseResult<Expr> =
    let tokens = skipNL tokens
    match peek tokens with
    | Some TokLBrace ->
        // Block scope: { ... }
        parseBlock (advance tokens)
    | _ ->
        // Inline scope: expression until newline
        parseExprImpl tokens >>= fun expr remaining ->
        // Consume trailing newline if present
        let remaining = 
            match peek remaining with
            | Some TokNewline -> advance remaining
            | _ -> remaining
        success expr remaining

and parseAssignment (tokens: Token list) : ParseResult<Expr> =
    parsePipeline tokens >>= fun left rest ->
    match peek rest with
    | Some (TokOp "=") ->
        advance rest |> parseAssignment >>= fun right remaining ->
        success (ExprAssign (left, right)) remaining
    | _ -> success left rest

and parsePipeline (tokens: Token list) : ParseResult<Expr> =
    parseChoice tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (TokOp "|>") ->
            advance toks |> parseChoice >>= fun right remaining ->
            match right with
            | ExprVar "compute" -> loop (ExprCompute acc) remaining
            | _ -> loop (ExprApp (right, [acc])) remaining
        | _ -> success acc toks
    loop left rest

and parseChoice (tokens: Token list) : ParseResult<Expr> =
    parseParallel tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (ChoiceOp op) ->
            advance toks |> parseParallel >>= fun right remaining ->
            loop (ExprBinOp (op, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseParallel (tokens: Token list) : ParseResult<Expr> =
    parseBind tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (ParallelOp op) ->
            advance toks |> parseBind >>= fun right remaining ->
            loop (ExprBinOp (op, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

// Helper to check for >> (two consecutive > tokens)
and isComposeOp (tokens: Token list) =
    match tokens with
    | t1 :: t2 :: _ when t1.Kind = TokOp ">" && t2.Kind = TokOp ">" -> true
    | _ -> false

and parseBind (tokens: Token list) : ParseResult<Expr> =
    parseApply tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (BindOp op) ->
            advance toks |> parseApply >>= fun right remaining ->
            loop (ExprBinOp (op, acc, right)) remaining
        // Handle >> as two consecutive > tokens (classic compose)
        | Some (TokOp ">") when isComposeOp toks ->
            // Consume both > tokens
            let afterCompose = advance (advance toks)
            parseApply afterCompose >>= fun right remaining ->
            loop (ExprBinOp (OpCompose, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseApply (tokens: Token list) : ParseResult<Expr> =
    parseArrayProduct tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (ApplyOp op) ->
            advance toks |> parseArrayProduct >>= fun right remaining ->
            loop (ExprBinOp (op, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseArrayProduct (tokens: Token list) : ParseResult<Expr> =
    parseOr tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (ArrayProductOp op) ->
            advance toks |> parseOr >>= fun right remaining ->
            loop (ExprBinOp (op, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseOr (tokens: Token list) : ParseResult<Expr> =
    parseAnd tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (OrOp op) ->
            advance toks |> parseAnd >>= fun right remaining ->
            loop (ExprBinOp (op, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseAnd (tokens: Token list) : ParseResult<Expr> =
    parseEquality tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (AndOp op) ->
            advance toks |> parseEquality >>= fun right remaining ->
            loop (ExprBinOp (op, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseEquality (tokens: Token list) : ParseResult<Expr> =
    parseComparison tokens >>= fun left rest ->
    match peek rest with
    | Some (EqualityOp op) ->
        advance rest |> parseComparison >>= fun right remaining ->
        success (ExprBinOp (op, left, right)) remaining
    | _ -> success left rest

and parseComparison (tokens: Token list) : ParseResult<Expr> =
    parseCons tokens >>= fun left rest ->
    match peek rest with
    | Some (ComparisonOp op) ->
        advance rest |> parseCons >>= fun right remaining ->
        success (ExprBinOp (op, left, right)) remaining
    | _ -> success left rest

and parseCons (tokens: Token list) : ParseResult<Expr> =
    parseAdditive tokens >>= fun left rest ->
    match peek rest with
    | Some TokColonColon ->
        advance rest |> parseCons >>= fun right remaining ->
        success (ExprBinOp (OpCons, left, right)) remaining
    | _ -> success left rest

and parseAdditive (tokens: Token list) : ParseResult<Expr> =
    parseMultiplicative tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (AdditiveOp op) ->
            advance toks |> parseMultiplicative >>= fun right remaining ->
            loop (ExprBinOp (op, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseMultiplicative (tokens: Token list) : ParseResult<Expr> =
    parsePower tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (MultiplicativeOp op) ->
            advance toks |> parsePower >>= fun right remaining ->
            loop (ExprBinOp (op, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parsePower (tokens: Token list) : ParseResult<Expr> =
    parseUnary tokens >>= fun left rest ->
    match peek rest with
    | Some (PowerOp op) ->
        advance rest |> parsePower >>= fun right remaining ->
        success (ExprBinOp (op, left, right)) remaining
    | _ -> success left rest

and parseUnary (tokens: Token list) : ParseResult<Expr> =
    match peek tokens with
    | Some (UnaryOp op) ->
        advance tokens |> parseUnary >>= fun expr remaining ->
        success (ExprUnaryOp (op, expr)) remaining
    | _ -> parsePostfix tokens

and parsePostfix (tokens: Token list) : ParseResult<Expr> =
    parsePrimary tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some TokLParen ->
            // Function call
            advance toks |> sepBy parseExprImpl TokComma >>= fun args afterArgs ->
            expect TokRParen afterArgs >>= fun _ remaining ->
            loop (ExprApp (acc, args)) remaining
        | Some TokLBracket ->
            // Poly-tuple indexing: args[k]
            advance toks |> parseExprImpl >>= fun index afterIndex ->
            expect TokRBracket afterIndex >>= fun _ remaining ->
            loop (ExprTupleIndex (acc, index)) remaining
        | Some TokDot ->
            // Field access
            advance toks |> expectIdent >>= fun field remaining ->
            loop (ExprField (acc, field)) remaining
        | _ -> success acc toks
    loop left rest

and parsePrimary (tokens: Token list) : ParseResult<Expr> =
    match peek tokens with
    // Literals (most common case first)
    | Some (LiteralTok lit) -> success (ExprLit lit) (advance tokens)
    
    // Variables
    | Some (TokIdent name) -> success (ExprVar name) (advance tokens)
    
    // Arity keywords (before other keywords)
    | Some (TokKeyword KwArity) -> success ExprArity (advance tokens)
    | Some (TokKeyword KwNth) -> success ExprNth (advance tokens)
    | Some (TokKeyword KwZero) -> success ExprZero (advance tokens)
    
    // rank(expr) - get rank of array
    | Some (TokKeyword KwRank) ->
        advance tokens |> expect TokLParen >>= fun _ afterLParen ->
        parseExprImpl afterLParen >>= fun expr afterExpr ->
        expect TokRParen afterExpr >>= fun _ remaining ->
        success (ExprRank expr) remaining
    
    // compute - standalone keyword (used after |>)
    | Some (TokKeyword KwCompute) ->
        success (ExprVar "compute") (advance tokens)
    
    // Lambda
    | Some (TokKeyword KwLambda) ->
        parseLambda (advance tokens)
    
    // Let expression
    | Some (TokKeyword KwLet) ->
        parseLet (advance tokens)
    
    // If expression
    | Some (TokKeyword KwIf) ->
        parseIf (advance tokens)
    
    // Match expression
    | Some (TokKeyword KwMatch) ->
        parseMatch (advance tokens)
    
    // method_for
    | Some (TokKeyword KwMethodFor) ->
        parseMethodFor (advance tokens)
    
    // object_for
    | Some (TokKeyword KwObjectFor) ->
        parseObjectFor (advance tokens)
    
    // zip(a, b, ...)
    | Some (TokKeyword KwZip) ->
        advance tokens |> expect TokLParen >>= fun _ afterLParen ->
        sepBy parseExprImpl TokComma afterLParen >>= fun exprs afterExprs ->
        expect TokRParen afterExprs >>= fun _ remaining ->
        success (ExprZip exprs) remaining
    
    // stack(a, b, ...)
    | Some (TokKeyword KwStack) ->
        advance tokens |> expect TokLParen >>= fun _ afterLParen ->
        sepBy parseExprImpl TokComma afterLParen >>= fun exprs afterExprs ->
        expect TokRParen afterExprs >>= fun _ remaining ->
        success (ExprStack exprs) remaining
    
    // sequence(a, b, ...)
    | Some (TokKeyword KwSequence) ->
        advance tokens |> expect TokLParen >>= fun _ afterLParen ->
        sepBy parseExprImpl TokComma afterLParen >>= fun exprs afterExprs ->
        expect TokRParen afterExprs >>= fun _ remaining ->
        success (ExprSequence exprs) remaining
    
    // replicate(n, expr)
    | Some (TokKeyword KwReplicate) ->
        advance tokens |> expect TokLParen >>= fun _ afterLParen ->
        parseExprImpl afterLParen >>= fun count afterCount ->
        expect TokComma afterCount >>= fun _ afterComma ->
        parseExprImpl afterComma >>= fun body afterBody ->
        expect TokRParen afterBody >>= fun _ remaining ->
        success (ExprReplicate (count, body)) remaining
    
    // guard(cond, body)
    | Some (TokKeyword KwGuard) ->
        advance tokens |> expect TokLParen >>= fun _ afterLParen ->
        parseExprImpl afterLParen >>= fun cond afterCond ->
        expect TokComma afterCond >>= fun _ afterComma ->
        parseExprImpl afterComma >>= fun body afterBody ->
        expect TokRParen afterBody >>= fun _ remaining ->
        success (ExprGuard (cond, body)) remaining
    
    // pure(expr)
    | Some (TokKeyword KwPure) ->
        advance tokens |> expect TokLParen >>= fun _ afterLParen ->
        parseExprImpl afterLParen >>= fun expr afterExpr ->
        expect TokRParen afterExpr >>= fun _ remaining ->
        success (ExprPure expr) remaining
    
    // reynolds(kernel) or reynolds(kernel, Antisymmetric)
    | Some (TokKeyword KwReynolds) ->
        advance tokens |> expect TokLParen >>= fun _ afterLParen ->
        parseExprImpl afterLParen >>= fun kernel afterKernel ->
        // Check for optional Symmetric/Antisymmetric
        let isAntisym, afterSpec =
            match peek afterKernel with
            | Some TokComma ->
                match peek (advance afterKernel) with
                | Some (TokIdent "Antisymmetric") -> true, advance (advance afterKernel)
                | Some (TokIdent "Symmetric") -> false, advance (advance afterKernel)
                | _ -> false, afterKernel
            | _ -> false, afterKernel
        expect TokRParen afterSpec >>= fun _ remaining ->
        success (ExprReynolds (kernel, isAntisym)) remaining
    
    // range<T>
    | Some (TokKeyword KwRange) ->
        advance tokens |> expect (TokOp "<") >>= fun _ afterLt ->
        parseTypeExpr afterLt >>= fun ty afterTy ->
        expect (TokOp ">") afterTy >>= fun _ remaining ->
        success (ExprRange ty) remaining
    
    // reverse<T>
    | Some (TokKeyword KwReverse) ->
        advance tokens |> expect (TokOp "<") >>= fun _ afterLt ->
        parseTypeExpr afterLt >>= fun ty afterTy ->
        expect (TokOp ">") afterTy >>= fun _ remaining ->
        success (ExprReverse ty) remaining
    
    // Parenthesized expression or tuple
    | Some TokLParen ->
        advance tokens |> parseParenExpr
    
    // Array literal
    | Some TokLBracket ->
        advance tokens |> sepBy parseExprImpl TokComma >>= fun elems afterElems ->
        expect TokRBracket afterElems >>= fun _ remaining ->
        success (ExprArrayLit elems) remaining
    
    // Block
    | Some TokLBrace ->
        parseBlock (advance tokens)
    
    | Some kind ->
        let line, col = currentPos tokens
        error (sprintf "Unexpected token: %A" kind) line col
    
    | None ->
        error "Unexpected end of input" 0 0

// ============================================================================
// Compound Expression Parsers
// ============================================================================

and parseLambda (tokens: Token list) : ParseResult<Expr> =
    expect TokLParen tokens >>= fun _ afterLParen ->
    sepBy parseLambdaParam TokComma afterLParen >>= fun parms afterParms ->
    expect TokRParen afterParms >>= fun _ afterRParen ->
    
    // Optional where clause (parallel to function declarations)
    let whereClause, afterWhere =
        match peek afterRParen with
        | Some (TokKeyword KwWhere) ->
            match parseWhereClause (advance afterRParen) with
            | Ok (w, rest) -> Some w, rest
            | Error _ -> None, afterRParen
        | _ -> None, afterRParen
    
    expect (TokOp "->") afterWhere >>= fun _ afterArrow ->
    // Lambda body: check for block or parse inline expression
    let afterArrow = skipNL afterArrow
    match peek afterArrow with
    | Some TokLBrace ->
        // Block body
        parseBlock (advance afterArrow) >>= fun body remaining ->
        success (ExprLambda (parms, whereClause, body)) remaining
    | _ ->
        // Inline body - but DON'T consume newline since lambda may be part of larger expr
        parseExprImpl afterArrow >>= fun body remaining ->
        success (ExprLambda (parms, whereClause, body)) remaining

and parseLambdaParam (tokens: Token list) : ParseResult<LambdaParam> =
    expectIdent tokens >>= fun name afterName ->
    match peek afterName with
    | Some TokColon ->
        advance afterName |> parseTypeExpr >>= fun ty remaining ->
        success { Name = name; Type = Some ty } remaining
    | _ ->
        success { Name = name; Type = None } afterName

and parseLet (tokens: Token list) : ParseResult<Expr> =
    // let [const|mut] pattern [: type] = value
    // Note: Blade does NOT have ML-style "let x = v in body" syntax
    // 'in' is only used for virtual arrays in for-loops
    let mutability, afterMut =
        match peek tokens with
        | Some (TokKeyword KwConst) -> BindConst, advance tokens
        | Some (TokKeyword KwMut) -> BindMut, advance tokens
        | _ -> BindLet, tokens
    
    parsePattern afterMut >>= fun pat afterPat ->
    let ty, afterTy =
        match peek afterPat with
        | Some TokColon ->
            match parseTypeExpr (advance afterPat) with
            | Ok (t, rest) -> Some t, rest
            | Error _ -> None, afterPat
        | _ -> None, afterPat
    
    expect (TokOp "=") afterTy >>= fun _ afterEq ->
    
    // Check for block or inline value
    let afterEq = skipNL afterEq
    match peek afterEq with
    | Some TokLBrace ->
        // Block value
        parseBlock (advance afterEq) >>= fun value afterValue ->
        let binding = { Mutability = mutability; Pattern = pat; Type = ty; Value = value }
        success (ExprLet (binding, ExprLit LitUnit)) afterValue
    | _ ->
        // Inline value
        parseExprImpl afterEq >>= fun value afterValue ->
        let binding = { Mutability = mutability; Pattern = pat; Type = ty; Value = value }
        success (ExprLet (binding, ExprLit LitUnit)) afterValue

and parseIf (tokens: Token list) : ParseResult<Expr> =
    parseExprImpl tokens >>= fun cond afterCond ->
    expect (TokKeyword KwThen) afterCond >>= fun _ afterThen ->
    parseExprImpl afterThen >>= fun thenBr afterThenBr ->
    expect (TokKeyword KwElse) afterThenBr >>= fun _ afterElse ->
    parseExprImpl afterElse >>= fun elseBr remaining ->
    success (ExprIf (cond, thenBr, elseBr)) remaining

and parseMatch (tokens: Token list) : ParseResult<Expr> =
    parseExprImpl tokens >>= fun scrutinee afterScrutinee ->
    expect (TokKeyword KwWith) afterScrutinee >>= fun _ afterWith ->
    many parseMatchCase (skipNL afterWith) >>= fun cases remaining ->
    success (ExprMatch (scrutinee, cases)) remaining

// FIXED: Properly propagate errors from guard parsing instead of swallowing them
and parseMatchCase (tokens: Token list) : ParseResult<MatchCase> =
    let tokens = skipNL tokens
    match peek tokens with
    | Some TokPipe ->
        advance tokens |> parsePattern >>= fun pat afterPat ->
        // Parse optional guard with proper error handling
        match peek afterPat with
        | Some (TokKeyword KwIf) ->
            // Parse guard expression, propagate errors
            advance afterPat |> parseGuardExpr >>= fun guard afterGuard ->
            expect (TokOp "->") afterGuard >>= fun _ afterArrow ->
            parseExprImpl afterArrow >>= fun body remaining ->
            success { Pattern = pat; Guard = Some guard; Body = body } remaining
        | _ ->
            expect (TokOp "->") afterPat >>= fun _ afterArrow ->
            parseExprImpl afterArrow >>= fun body remaining ->
            success { Pattern = pat; Guard = None; Body = body } remaining
    | _ ->
        let line, col = currentPos tokens
        error "Expected '|' to start match case" line col

// Parse guard expression - stops before ->
// This is a restricted expression parser that doesn't consume ->
and parseGuardExpr (tokens: Token list) : ParseResult<Expr> =
    parseGuardOr tokens

and parseGuardOr (tokens: Token list) : ParseResult<Expr> =
    parseGuardAnd tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (TokOp "||") ->
            advance toks |> parseGuardAnd >>= fun right remaining ->
            loop (ExprBinOp (OpOr, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseGuardAnd (tokens: Token list) : ParseResult<Expr> =
    parseGuardComparison tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (TokOp "&&") ->
            advance toks |> parseGuardComparison >>= fun right remaining ->
            loop (ExprBinOp (OpAnd, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseGuardComparison (tokens: Token list) : ParseResult<Expr> =
    parseGuardAdditive tokens >>= fun left rest ->
    match peek rest with
    | Some (TokOp "==") ->
        advance rest |> parseGuardAdditive >>= fun right remaining ->
        success (ExprBinOp (OpEq, left, right)) remaining
    | Some (TokOp "!=") ->
        advance rest |> parseGuardAdditive >>= fun right remaining ->
        success (ExprBinOp (OpNeq, left, right)) remaining
    | Some (TokOp "<") ->
        advance rest |> parseGuardAdditive >>= fun right remaining ->
        success (ExprBinOp (OpLt, left, right)) remaining
    | Some (TokOp "<=") ->
        advance rest |> parseGuardAdditive >>= fun right remaining ->
        success (ExprBinOp (OpLe, left, right)) remaining
    | Some (TokOp ">") ->
        advance rest |> parseGuardAdditive >>= fun right remaining ->
        success (ExprBinOp (OpGt, left, right)) remaining
    | Some (TokOp ">=") ->
        advance rest |> parseGuardAdditive >>= fun right remaining ->
        success (ExprBinOp (OpGe, left, right)) remaining
    | _ -> success left rest

and parseGuardAdditive (tokens: Token list) : ParseResult<Expr> =
    parseGuardMultiplicative tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (TokOp "+") ->
            advance toks |> parseGuardMultiplicative >>= fun right remaining ->
            loop (ExprBinOp (OpAdd, acc, right)) remaining
        | Some (TokOp "-") ->
            advance toks |> parseGuardMultiplicative >>= fun right remaining ->
            loop (ExprBinOp (OpSub, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseGuardMultiplicative (tokens: Token list) : ParseResult<Expr> =
    parseGuardPrimary tokens >>= fun left rest ->
    let rec loop acc toks =
        match peek toks with
        | Some (TokOp "*") ->
            advance toks |> parseGuardPrimary >>= fun right remaining ->
            loop (ExprBinOp (OpMul, acc, right)) remaining
        | Some (TokOp "/") ->
            advance toks |> parseGuardPrimary >>= fun right remaining ->
            loop (ExprBinOp (OpDiv, acc, right)) remaining
        | _ -> success acc toks
    loop left rest

and parseGuardPrimary (tokens: Token list) : ParseResult<Expr> =
    match peek tokens with
    | Some (LiteralTok lit) -> success (ExprLit lit) (advance tokens)
    | Some (TokIdent name) -> 
        let afterName = advance tokens
        // Allow function calls in guards
        match peek afterName with
        | Some TokLParen ->
            advance afterName |> sepBy parseGuardExpr TokComma >>= fun args afterArgs ->
            expect TokRParen afterArgs >>= fun _ remaining ->
            success (ExprApp (ExprVar name, args)) remaining
        | _ -> success (ExprVar name) afterName
    | Some TokLParen ->
        advance tokens |> parseGuardExpr >>= fun expr afterExpr ->
        expect TokRParen afterExpr >>= fun _ remaining ->
        success expr remaining
    | Some (TokOp "-") ->
        advance tokens |> parseGuardPrimary >>= fun expr remaining ->
        success (ExprUnaryOp (OpNeg, expr)) remaining
    | Some (TokOp "!") ->
        advance tokens |> parseGuardPrimary >>= fun expr remaining ->
        success (ExprUnaryOp (OpNot, expr)) remaining
    | Some kind ->
        let line, col = currentPos tokens
        error (sprintf "Unexpected token in guard: %A" kind) line col
    | None ->
        error "Expected guard expression but got EOF" 0 0

and parseMethodFor (tokens: Token list) : ParseResult<Expr> =
    expect TokLParen tokens >>= fun _ afterLParen ->
    sepBy parseExprImpl TokComma afterLParen >>= fun arrays afterArrays ->
    expect TokRParen afterArrays >>= fun _ remaining ->
    success (ExprMethodFor arrays) remaining

and parseObjectFor (tokens: Token list) : ParseResult<Expr> =
    expect TokLParen tokens >>= fun _ afterLParen ->
    parseExprImpl afterLParen >>= fun kernel afterKernel ->
    expect TokRParen afterKernel >>= fun _ remaining ->
    success (ExprObjectFor kernel) remaining

and parseParenExpr (tokens: Token list) : ParseResult<Expr> =
    match peek tokens with
    | Some TokRParen ->
        success (ExprTuple []) (advance tokens)
    | _ ->
        parseExprImpl tokens >>= fun first afterFirst ->
        match peek afterFirst with
        | Some TokRParen ->
            success first (advance afterFirst)
        | Some TokComma ->
            advance afterFirst |> sepBy parseExprImpl TokComma >>= fun rest afterRest ->
            expect TokRParen afterRest >>= fun _ remaining ->
            success (ExprTuple (first :: rest)) remaining
        | _ ->
            let line, col = currentPos afterFirst
            error "Expected ')' or ',' in parenthesized expression" line col

and parseBlock (tokens: Token list) : ParseResult<Expr> =
    let rec loop stmts toks =
        let toks = skipNL toks
        match peek toks with
        | Some TokRBrace ->
            // End of block - last expression (if any) is the return value
            let (statements, finalExpr) = 
                match List.rev stmts with
                | [] -> [], None
                | StmtExpr e :: rest -> List.rev rest, Some e
                | all -> all, None
            success (ExprBlock (statements, finalExpr)) (advance toks)
        | Some TokSemi ->
            // Explicit semicolon - skip it
            loop stmts (advance toks)
        | Some (TokKeyword KwLet) ->
            advance toks |> parseLetStmt >>= fun stmt remaining ->
            // Consume optional terminator (newline or semicolon)
            let remaining = skipTerminator remaining
            loop (stmt :: stmts) remaining
        | Some (TokKeyword KwFunction) ->
            // Nested function declaration - parse as let binding of lambda
            advance toks |> parseNestedFunction >>= fun stmt remaining ->
            let remaining = skipTerminator remaining
            loop (stmt :: stmts) remaining
        | Some _ ->
            parseExprImpl toks >>= fun expr remaining ->
            let remaining = skipTerminator remaining
            loop (StmtExpr expr :: stmts) remaining
        | None ->
            error "Unexpected EOF in block" 0 0
    loop [] tokens

and skipTerminator toks =
    match peek toks with
    | Some TokNewline -> advance toks
    | Some TokSemi -> advance toks
    | _ -> toks

and parseNestedFunction (tokens: Token list) : ParseResult<Stmt> =
    // Parse: function name(params) where ... -> Type = body
    // Convert to: let name = lambda(params) where ... -> Type -> body
    expectIdent tokens >>= fun name afterName ->
    expect TokLParen afterName >>= fun _ afterLParen ->
    sepBy parseLambdaParam TokComma afterLParen >>= fun parms afterParms ->
    expect TokRParen afterParms >>= fun _ afterRParen ->
    
    // Skip newlines between clauses
    let afterRParen = skipNL afterRParen
    
    // Optional where clause
    let whereClause, afterWhere =
        match peek afterRParen with
        | Some (TokKeyword KwWhere) ->
            match parseWhereClause (advance afterRParen) with
            | Ok (w, rest) -> Some w, skipNL rest
            | Error _ -> None, afterRParen
        | _ -> None, afterRParen
    
    // Optional return type
    let retType, afterRet =
        match peek afterWhere with
        | Some (TokOp "->") ->
            match parseTypeExpr (advance afterWhere) with
            | Ok (t, rest) -> Some t, skipNL rest
            | Error _ -> None, afterWhere
        | _ -> None, afterWhere
    
    expect (TokOp "=") afterRet >>= fun _ afterEq ->
    parseInlineOrBlock afterEq >>= fun body remaining ->
    
    // Create a let binding: let name = lambda(params) where ... -> body
    let lambda = ExprLambda (parms, whereClause, body)
    let binding = {
        Pattern = PatVar name
        Type = retType
        Value = lambda
        Mutability = BindConst
    }
    success (StmtLet binding) remaining

and parseLetStmt (tokens: Token list) : ParseResult<Stmt> =
    let mutability, afterMut =
        match peek tokens with
        | Some (TokKeyword KwConst) -> BindConst, advance tokens
        | Some (TokKeyword KwMut) -> BindMut, advance tokens
        | _ -> BindLet, tokens
    
    parsePattern afterMut >>= fun pat afterPat ->
    let ty, afterTy =
        match peek afterPat with
        | Some TokColon ->
            match parseTypeExpr (advance afterPat) with
            | Ok (t, rest) -> Some t, rest
            | Error _ -> None, afterPat
        | _ -> None, afterPat
    
    expect (TokOp "=") afterTy >>= fun _ afterEq ->
    parseExprImpl afterEq >>= fun value remaining ->
    
    success (StmtLet {
        Mutability = mutability
        Pattern = pat
        Type = ty
        Value = value
    }) remaining

// ============================================================================
// Declaration Parsing
// ============================================================================

let parseParamDecl (tokens: Token list) : ParseResult<ParamDecl> =
    expectIdent tokens >>= fun name afterName ->
    match peek afterName with
    | Some TokColon ->
        advance afterName |> parseTypeExpr >>= fun ty remaining ->
        success { Name = name; Type = Some ty; Mutability = Immutable } remaining
    | _ ->
        success { Name = name; Type = None; Mutability = Immutable } afterName

let parseFunctionDecl (tokens: Token list) : ParseResult<Decl> =
    expectIdent tokens >>= fun name afterName ->
    expect TokLParen afterName >>= fun _ afterLParen ->
    sepBy parseParamDecl TokComma afterLParen >>= fun parms afterParms ->
    expect TokRParen afterParms >>= fun _ afterRParen ->
    
    // Skip newlines between parts of function declaration
    let afterRParen = skipNL afterRParen
    
    // Optional where clause
    let whereClause, afterWhere =
        match peek afterRParen with
        | Some (TokKeyword KwWhere) ->
            match parseWhereClause (advance afterRParen) with
            | Ok (w, rest) -> Some w, skipNL rest
            | Error _ -> None, afterRParen
        | _ -> None, afterRParen
    
    // Optional return type (either : Type or -> Type)
    let retType, afterRet =
        match peek afterWhere with
        | Some TokColon ->
            match parseTypeExpr (advance afterWhere) with
            | Ok (t, rest) -> Some t, skipNL rest
            | Error _ -> None, afterWhere
        | Some (TokOp "->") ->
            match parseTypeExpr (advance afterWhere) with
            | Ok (t, rest) -> Some t, skipNL rest
            | Error _ -> None, afterWhere
        | _ -> None, afterWhere
    
    expect (TokOp "=") afterRet >>= fun _ afterEq ->
    parseInlineOrBlock afterEq >>= fun body remaining ->
    
    success (DeclFunction {
        Name = name
        TypeParams = []
        Params = parms
        WhereClause = whereClause
        ReturnType = retType
        Body = body
        IsStatic = false
    }) remaining

let parseTopLevelLet (tokens: Token list) : ParseResult<Decl> =
    let mutability, afterMut =
        match peek tokens with
        | Some (TokKeyword KwConst) -> BindConst, advance tokens
        | Some (TokKeyword KwMut) -> BindMut, advance tokens
        | _ -> BindLet, tokens
    
    parsePattern afterMut >>= fun pat afterPat ->
    let ty, afterTy =
        match peek afterPat with
        | Some TokColon ->
            match parseTypeExpr (advance afterPat) with
            | Ok (t, rest) -> Some t, rest
            | Error _ -> None, afterPat
        | _ -> None, afterPat
    
    expect (TokOp "=") afterTy >>= fun _ afterEq ->
    parseExprImpl afterEq >>= fun value remaining ->
    
    success (DeclLet {
        Mutability = mutability
        Pattern = pat
        Type = ty
        Value = value
    }) remaining

let parseDecl (tokens: Token list) : ParseResult<Decl> =
    match peek tokens with
    | Some (TokKeyword KwFunction) ->
        parseFunctionDecl (advance tokens)
    | Some (TokKeyword KwLet) ->
        parseTopLevelLet (advance tokens)
    | Some kind ->
        let line, col = currentPos tokens
        error (sprintf "Expected declaration but got %A" kind) line col
    | None ->
        error "Expected declaration but got EOF" 0 0

// ============================================================================
// Module and Program Parsing
// ============================================================================

let parseModule (tokens: Token list) : ParseResult<ModuleDecl> =
    let rec loop decls toks =
        let toks = skipNL toks
        match peek toks with
        | Some TokEOF | None ->
            success (List.rev decls) toks
        | _ ->
            parseDecl toks >>= fun decl remaining ->
            let located = { Value = decl; Span = noSpan }
            loop (located :: decls) remaining
    
    loop [] tokens >>= fun decls remaining ->
    success {
        Name = ["Main"]
        Imports = []
        Decls = decls
    } remaining

let parseProgram (source: string) : Result<Program, ParseError> =
    let tokens = tokenizeWithNewlines source
    match parseModule tokens with
    | Ok (modul, _) -> Ok { Modules = [modul] }
    | Error e -> Error e

// ============================================================================
// Initialize Forward Reference
// ============================================================================

do parseExprRef := parseExprImpl
do parseBodyRef := parseInlineOrBlock
