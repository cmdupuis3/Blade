# Type System Refactor: Moving Symmetry Analysis to Type Checking

## Current Architecture

```
Source → Lexer → Parser → AST → Lowering → IR
                                    ↑
                          symmetry analysis here
                          (identity tracking, comm groups,
                           SymcomState, speedup calculation)
```

**Problems:**
1. Type information computed during IR generation, not available earlier
2. IDE/LSP would need full lowering to show types
3. Lowering.fs mixes concerns (type inference + IR generation)

## Proposed Architecture

```
Source → Lexer → Parser → AST → TypeCheck → TypedAST → Lowering → IR
                                    ↑
                          symmetry analysis here
```

## New Module Structure

### 1. `Types.fs` (extract from AST.fs and IR.fs)
Already have most type definitions, but consolidate:
- `IRType`, `IRArrayType`, `IRIndexType`
- `ArrayIdentity`, `SymcomState`
- `ElemType`, `IndexSymmetry`, `IndexKind`

### 2. `TypeCheck.fs` (NEW)
Main type checking/inference module:

```fsharp
module Blade.TypeCheck

type TypeEnv = {
    Variables: Map<string, TypedVarInfo>
    Functions: Map<string, FunctionSig>
    Types: Map<string, TypeDef>
    CurrentCommGroups: int list list
}

type TypedVarInfo = {
    Name: string
    Type: IRType
    Identity: ArrayIdentity option
    IsMutable: bool
}

/// Main entry point
val typeCheck: Program -> Result<TypedProgram, TypeError>

/// Infer type of expression
val inferExpr: TypeEnv -> Expr -> Result<TypedExpr, TypeError>

/// Compute symmetry info for method_for application
val computeApplicationType: 
    TypeEnv -> 
    loopArrays: TypedExpr list -> 
    kernel: TypedExpr -> 
    ApplicationTypeInfo

type ApplicationTypeInfo = {
    OutputType: IRType
    SymcomStates: SymcomState list
    TriangularLevels: bool list
    Speedup: int64
    ReynoldsSpeedup: int64
    HasReynolds: bool
}
```

### 3. `TypedAst.fs` (NEW)
AST annotated with types:

```fsharp
module Blade.TypedAst

type TypedExpr = {
    Expr: TypedExprKind
    Type: IRType
    Span: Span
}

and TypedExprKind =
    | TExprLit of Literal
    | TExprVar of name: string * identity: ArrayIdentity option
    | TExprBinOp of BinOpMode * BinOp * TypedExpr * TypedExpr
    | TExprApp of func: TypedExpr * args: TypedExpr list
    | TExprLambda of TypedLambda
    | TExprMethodFor of TypedMethodFor
    | TExprApplyCombinator of TypedApply  // carries symmetry info
    // ... etc

and TypedLambda = {
    Params: TypedParam list
    Body: TypedExpr
    ReturnType: IRType
    CommGroups: int list list
    Captures: (string * IRType) list
}

and TypedMethodFor = {
    Arrays: TypedExpr list
    Identities: ArrayIdentity list
    ArrayTypes: IRArrayType list
    SDimsPerArray: int list
}

and TypedApply = {
    Loop: TypedExpr
    Kernel: TypedExpr
    OutputType: IRType
    SymcomStates: SymcomState list
    TriangularLevels: bool list
    Speedup: int64
    ReynoldsSpeedup: int64
}

type TypedDecl =
    | TDeclFunction of TypedFunctionDecl
    | TDeclLet of TypedBinding
    | TDeclType of TypeDecl  // type decls don't change
    // ...

type TypedProgram = {
    Modules: TypedModule list
}
```

### 4. `Lowering.fs` (SIMPLIFIED)
Now just translates TypedAST → IR, no inference:

```fsharp
/// Lowering becomes straightforward translation
let rec lowerExpr (texpr: TypedExpr) : IRExpr =
    match texpr.Expr with
    | TExprLit lit -> IRLit (lowerLit lit)
    | TExprVar (name, _) -> IRVar (lookupId name)
    | TExprBinOp (mode, op, l, r) -> 
        IRBinOp (lowerMode mode, lowerOp op, lowerExpr l, lowerExpr r)
    | TExprApplyCombinator info ->
        // All symmetry info already computed, just package it
        IRApplyCombinator {
            Loop = lowerExpr info.Loop
            Kernel = lowerExpr info.Kernel
            OutputType = info.OutputType
            SymcomStates = info.SymcomStates
            // ... etc
        }
```

## Migration Steps

### Step 1: Create TypedAst.fs
- Define TypedExpr and related types
- Keep it minimal initially

### Step 2: Create TypeCheck.fs  
- Move `LowerEnv` → `TypeEnv`
- Move identity tracking logic
- Move `computeAllSymcomStates`, `computeTriangularLevels`, etc. calls
- Implement `inferExpr` that produces TypedExpr

### Step 3: Update Lowering.fs
- Change input from `AST.Expr` to `TypedAst.TypedExpr`
- Remove type inference code
- Simplify to pure translation

### Step 4: Update Main.fs
- Add type checking phase to pipeline
- Update test runner

## What Moves Where

### From Lowering.fs to TypeCheck.fs:
- `LowerEnv` type (renamed to `TypeEnv`)
- `bindVar*` functions
- `collectFreeVars`
- `getArrayType`
- `inferArrayType`
- `inferLambdaReturnType`
- Identity tracking in `lowerBinding`
- Comm group extraction from lambda where clauses
- Symmetry computation calls (the functions stay in IR.fs but are called from TypeCheck)

### Stays in IR.fs:
- `computeAllSymcomStates`
- `computeTriangularLevels`  
- `computePartialProductSpeedup`
- `buildLoopLevelStructure`
- Type definitions (IRType, etc.)

### Stays in Lowering.fs (simplified):
- Pure translation from TypedExpr → IRExpr
- No environment threading for types
- No inference logic

## Benefits

1. **IDE Support**: Type info available without full compilation
2. **Separation of Concerns**: Type checking vs code generation
3. **Incremental Checking**: Can re-typecheck single file
4. **Better Errors**: Type errors reported before lowering
5. **Testability**: Can test type inference independently

## Estimated Effort

- TypedAst.fs: ~150 lines, 30 min
- TypeCheck.fs: ~400 lines, 2 hours  
- Lowering.fs changes: ~200 lines removed, ~100 rewritten, 1 hour
- Testing/debugging: 1 hour

**Total: ~4-5 hours**

## Alternative: Minimal Change

If full refactor is too much, a lighter approach:

1. Keep Lowering.fs as-is
2. Add `typeCheckOnly` function that runs lowering but discards IR
3. Cache type info for LSP queries

This is quicker but doesn't solve the architectural issues.
